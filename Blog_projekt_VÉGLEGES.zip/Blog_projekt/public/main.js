const apiUrl = 'http://localhost:3000/posts'

const postForm = document.getElementById('postForm')
const postsContainer = document.getElementById('posts')

const postIdInput = document.getElementById('postId')
const authorInput = document.getElementById('author')
const titleInput = document.getElementById('title')
const categoryInput = document.getElementById('category')
const contentInput = document.getElementById('content')
const cancelEditBtn = document.getElementById('cancelEdit')

function fetchPosts() {
  fetch(apiUrl)
    .then(res => res.json())
    .then(posts => {
      postsContainer.innerHTML = ''
      posts.forEach(post => {
        postsContainer.appendChild(createPostElement(post))
      })
    })
    .catch(err => alert('Hiba a beolvasáskor: ' + err))
}

function createPostElement(post) {
  const postEl = document.createElement('div')
  postEl.className = 'post'

  if (postIdInput.value === String(post.id)) {
    postEl.classList.add('edit-mode')
  }

  const createdDate = new Date(post.created_at).toLocaleString()
  const updatedDate = new Date(post.updated_at).toLocaleString()

  postEl.innerHTML = `
    <div class="post-header">
      <h2 class="post-title">${escapeHtml(post.title)}</h2>
      <div class="post-actions">
        <button onclick="editPost(${post.id})">Szerkesztés</button>
        <button onclick="deletePost(${post.id})" style="color:#c0392b;">Törlés</button>
      </div>
    </div>
    <div class="post-meta">Szerző: ${escapeHtml(post.author)} | Kategória: ${escapeHtml(post.category)}<br />
      Létrehozva: ${createdDate} | Utolsó módosítás: ${updatedDate}
    </div>
    <div class="post-content">${escapeHtml(post.content)}</div>
  `

  return postEl
}

function escapeHtml(text) {
  if (!text) return ''
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
}

postForm.addEventListener('submit', e => {
  e.preventDefault()

  const id = postIdInput.value
  const data = {
    author: authorInput.value.trim(),
    title: titleInput.value.trim(),
    category: categoryInput.value,
    content: contentInput.value.trim(),
  }

  if (!data.author || !data.title || !data.category || !data.content) {
    alert('Kérlek tölts ki minden mezőt!')
    return
  }

  if (id) {
    fetch(`${apiUrl}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    }).then(res => {
      if (!res.ok) throw new Error('Nem sikerült frissíteni')
      return res.json()
    }).then(() => {
      resetForm()
      fetchPosts()
    }).catch(err => alert(err))
  } else {
    fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    }).then(res => {
      if (!res.ok) throw new Error('Nem sikerült létrehozni')
      return res.json()
    }).then(() => {
      resetForm()
      fetchPosts()
    }).catch(err => alert(err))
  }
})

function editPost(id) {
  fetch(`${apiUrl}/${id}`)
    .then(res => {
      if (!res.ok) throw new Error('Nem található a poszt')
      return res.json()
    })
    .then(post => {
      postIdInput.value = post.id
      authorInput.value = post.author
      titleInput.value = post.title
      categoryInput.value = post.category
      contentInput.value = post.content
      cancelEditBtn.style.display = 'inline-block'
    })
    .catch(err => alert(err))
}

function deletePost(id) {
  if (!confirm('Biztosan törlöd ezt a blogposztot?')) return
  fetch(`${apiUrl}/${id}`, { method: 'DELETE' })
    .then(res => {
      if (!res.ok) throw new Error('Nem sikerült törölni')
      return res.json()
    })
    .then(() => fetchPosts())
    .catch(err => alert(err))
}

function resetForm() {
  postIdInput.value = ''
  authorInput.value = ''
  titleInput.value = ''
  categoryInput.value = ''
  contentInput.value = ''
  cancelEditBtn.style.display = 'none'
}

cancelEditBtn.addEventListener('click', resetForm)

fetchPosts()
