const express = require('express')
const sqlite3 = require('sqlite3').verbose()
const cors = require('cors')
const bodyParser = require('body-parser')
const path = require('path')

const app = express()
const PORT = 3000

app.use(cors())
app.use(bodyParser.json())

app.use(express.static(path.join(__dirname, 'public')))

const db = new sqlite3.Database('./blog.db')

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    author TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )`)
})

app.get('/posts', (req, res) => {
  db.all('SELECT * FROM posts ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message })
    res.json(rows)
  })
})

app.get('/posts/:id', (req, res) => {
  const id = req.params.id
  db.get('SELECT * FROM posts WHERE id = ?', [id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message })
    if (!row) return res.status(404).json({ error: 'Poszt nem található' })
    res.json(row)
  })
})

app.post('/posts', (req, res) => {
  const { author, title, category, content } = req.body
  const now = new Date().toISOString()
  db.run(`INSERT INTO posts (author, title, category, content, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?)`,
    [author, title, category, content, now, now],
    function(err) {
      if (err) return res.status(500).json({ error: err.message })
      res.json({ id: this.lastID, author, title, category, content, created_at: now, updated_at: now })
    })
})

app.put('/posts/:id', (req, res) => {
  const { author, title, category, content } = req.body
  const updated_at = new Date().toISOString()
  db.run(`UPDATE posts SET author = ?, title = ?, category = ?, content = ?, updated_at = ? WHERE id = ?`,
    [author, title, category, content, updated_at, req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message })
      res.json({ message: 'Updated successfully' })
    })
})

app.delete('/posts/:id', (req, res) => {
  db.run(`DELETE FROM posts WHERE id = ?`, [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message })
    res.json({ message: 'Deleted successfully' })
  })
})

app.listen(PORT, () => {
  console.log(`API running on http://localhost:${PORT}`)
})
